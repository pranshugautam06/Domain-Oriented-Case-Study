<?php

namespace LaravelDomainOriented\Tests\Cases;

abstract class BasicTestCase extends BaseTestCase
{

}
